const mongoose = require('mongoose');
const { body, validationResult } = require('express-validator');
const { ObjectId } = mongoose.Types;
const Recipe = require('../schemas/RecipeSchema');

const validateObjectId = (req, res, next) => {
  const id = req.params._id || req.params.id;
  if (!id) {
    return res.status(400).json({ error: 'ID parameter is required' });
  }
  if (!ObjectId.isValid(id)) {
    return res.status(400).json({ error: 'Invalid ID format' });
  }
  return next();
};

const validateMovieData = [
  body('title')
    .notEmpty()
    .withMessage('Title is required.')
    .isLength({ min: 2, max: 70 })
    .withMessage('Title must be between 2 and 70 characters.'),
  body('director')
    .notEmpty()
    .withMessage('Director is required.')
    .isLength({ min: 2, max: 30 })
    .withMessage('Director must be between 2 and 30 characters.'),
  body('language')
    .notEmpty()
    .withMessage('Language is required.')
    .isLength({ min: 2, max: 20 })
    .withMessage('Languages must be between 2 and 20 characters.'),
  body('year')
    .notEmpty()
    .withMessage('Year is required.')
    .isNumeric()
    .withMessage('Year must be a number.')
    .isLength({ min: 4, max: 4 })
    .withMessage('Year must be 4 digits.'),
  body('genre')
    .notEmpty()
    .withMessage('Genre is required.')
    .isArray({ min: 1 })
    .withMessage('At least one genre must be specified.'),
  body('genre.*')
    .isString()
    .withMessage('Genre must be a string.')
    .trim()
    .isLength({ min: 2, max: 15 })
    .withMessage('Genre must be between 2 and 15 characters.')
    .notEmpty()
    .withMessage('Genre cannot be empty.'),
  body('synopsis')
    .notEmpty()
    .withMessage('Synopsis is required.')
    .isLength({ min: 10, max: 300 })
    .withMessage('Synopsis must be between 10 and 300 characters.'),
];

const validateRecipeRules = [
  body('name')
    .isString()
    .withMessage('Name must be a string')
    .notEmpty()
    .withMessage('Name is required'),
  body('serves')
    .isInt({ min: 1 })
    .withMessage('Serves must be an integer greater than 0')
    .notEmpty()
    .withMessage('Serves is required'),
  body('description')
    .optional()
    .isString()
    .withMessage('Description must be a string'),
  body('ingredients')
    .isArray({ min: 1 })
    .withMessage('Ingredients must be a non-empty array'),
  body('ingredients.*.amount')
    .isFloat({ gt: 0 })
    .withMessage('Ingredient amount must be a number greater than 0')
    .notEmpty()
    .withMessage('Ingredient amount is required'),
  body('ingredients.*.amountString')
    .isString()
    .withMessage('Ingredient amountString must be a string')
    .notEmpty()
    .withMessage('Ingredient amountString is required'),
  body('ingredients.*.measurement')
    .isString()
    .withMessage('Ingredient measurement must be a string')
    .notEmpty()
    .withMessage('Ingredient measurement is required'),
  body('ingredients.*.measurementDescription')
    .optional()
    .isString()
    .withMessage('Ingredient measurementDescription must be a string'),
  body('ingredients.*.ingredient')
    .isString()
    .withMessage('Ingredient name must be a string')
    .notEmpty()
    .withMessage('Ingredient name is required'),
  body('ingredients.*.ingredientDescription')
    .optional()
    .isString()
    .withMessage('Ingredient description must be a string'),
  body('instructions')
    .isArray({ min: 1 })
    .withMessage('Instructions must be a non-empty array'),
  body('instructions.*.stepNumber')
    .isInt({ min: 1 })
    .withMessage('Instruction stepNumber must be an integer greater than 0')
    .notEmpty()
    .withMessage('Step Number is required'),
  body('instructions.*.instruction')
    .isString()
    .withMessage('Instruction must be a string')
    .notEmpty()
    .withMessage('Instruction is required'),
];

const validateRecipeUpdateRules = [
  body('name').isString().withMessage('Name must be a string'),
  body('serves')
    .isInt({ min: 1 })
    .withMessage('Serves must be an integer greater than 0'),
  body('description').isString().withMessage('Description must be a string'),
  body('ingredients')
    .isArray({ min: 1 })
    .withMessage('Ingredients must be a non-empty array'),
  body('ingredients.*.amount')
    .isFloat({ gt: 0 })
    .withMessage('Ingredient amount must be a number greater than 0'),
  body('ingredients.*.amountString')
    .isString()
    .withMessage('Ingredient amountString must be a string')
    .notEmpty()
    .withMessage('Ingredient amountString is required'),
  body('ingredients.*.measurement')
    .isString()
    .withMessage('Ingredient measurement must be a string')
    .notEmpty()
    .withMessage('Ingredient measurement is required'),
  body('ingredients.*.measurementDescription')
    .optional()
    .isString()
    .withMessage('Ingredient measurementDescription must be a string'),
  body('ingredients.*.ingredient')
    .isString()
    .withMessage('Ingredient name must be a string')
    .notEmpty()
    .withMessage('Ingredient name is required'),
  body('ingredients.*.ingredientDescription')
    .optional()
    .isString()
    .withMessage('Ingredient description must be a string'),
  body('instructions')
    .isArray({ min: 1 })
    .withMessage('Instructions must be a non-empty array'),
  body('instructions.*.stepNumber')
    .isInt({ min: 1 })
    .withMessage('Instruction stepNumber must be an integer greater than 0'),
  body('instructions.*.instruction')
    .isString()
    .withMessage('Instruction must be a string'),
];

const validateRecipeNameRules = [
  body('name')
    .isString()
    .withMessage('Recipe name must be a string')
    .notEmpty()
    .withMessage('Recipe name is required')
    .custom(async (value) => {
      const existing = await Recipe.findOne({ name: value });
      if (existing) {
        throw new Error('Recipe name already in use');
      }
    }),
];
const validateBookArray = [
  body().isArray().withMessage('Request body must be an array.'),
  body('*.title')
    .notEmpty()
    .withMessage('Title is required.')
    .isString()
    .withMessage('Title must be a string.')
    .isLength({ min: 2, max: 70 })
    .withMessage('Title must be between 2 and 70 characters.'),
  body('*.author')
    .notEmpty()
    .withMessage('Author is required.')
    .isString()
    .withMessage('Author must be a string.')
    .isLength({ min: 2, max: 50 })
    .withMessage('Author must be between 2 and 50 characters.'),
  body('*.year')
    .notEmpty()
    .withMessage('Year is required.')
    .matches(/^\d{4}$/)
    .withMessage('Year must be a 4-digit number.'),
];
const validateBookData = [
  body('title')
    .notEmpty()
    .withMessage('Title is required.')
    .isString()
    .withMessage('Title must be a string.')
    .isLength({ min: 2, max: 70 })
    .withMessage('Title must be between 2 and 70 characters.'),
  body('author')
    .notEmpty()
    .withMessage('Author is required.')
    .isString()
    .withMessage('Author must be a string.')
    .isLength({ min: 2, max: 50 })
    .withMessage('Author must be between 2 and 50 characters.'),
  body('year')
    .notEmpty()
    .withMessage('Year is required.')
    .matches(/^\d{4}$/)
    .withMessage('Year must be a 4-digit number.'),
];

const validateScriptureData = [
  body('book')
    .notEmpty()
    .withMessage('Book is required')
    .trim()
    .isLength({ min: 3, max: 25 })
    .withMessage('Book must be between 3 and 25 characters'),
  body('chapter')
    .notEmpty()
    .withMessage('Chapter is required')
    .trim()
    .isLength({ min: 1, max: 2 })
    .withMessage('Chapter must be 1 or 2 characters'),
  body('verse')
    .notEmpty()
    .withMessage('Verse(s) must be included')
    .trim()
    .isLength({ min: 1, max: 25 })
    .withMessage('Verse must be between 25 characters or less'),
  body('text')
    .notEmpty()
    .withMessage('Verse(s) must be included')
    .trim()
    .isLength({ min: 1, max: 1000 })
    .withMessage('Verse must be between 1000 characters or less'),
];

const validateSpeakerData = [
  body('firstName')
    .trim()
    .notEmpty()
    .withMessage('First name is required!')
    .isLength({ min: 2, max: 25 })
    .withMessage('First name must be between 2 and 25 characters!'),
  body('lastName')
    .trim()
    .notEmpty()
    .withMessage('Last name is required!')
    .isLength({ min: 2, max: 25 })
    .withMessage('Last name must be between 2 and 25 characters!'),
  body('age')
    .notEmpty()
    .withMessage('Age is required!')
    .isInt({ min: 0, max: 110 })
    .withMessage('Age needs to be between 0 and 110!'),
  body('birthYear')
    .notEmpty()
    .withMessage('Birth year is required!')
    .isInt({ min: 1900, max: new Date().getFullYear() })
    .withMessage(
      'Birth Year is required and has to be a 4 digit number between 1900 and the current year!',
    ),
  body('quote')
    .trim()
    .notEmpty()
    .withMessage('Quote is required!')
    .isLength({ min: 2, max: 1000 })
    .withMessage('A Quote is required to be between 2 and 1000 characters'),
];

const validateSpeakerUpdateData = [
  body('firstName')
    .optional()
    .trim()
    .isLength({ min: 2, max: 25 })
    .withMessage('First name must be between 2 and 25 characters!'),
  body('lastName')
    .optional()
    .trim()
    .isLength({ min: 2, max: 25 })
    .withMessage('Last name must be between 2 and 25 characters!'),
  body('age')
    .optional()
    .isInt({ min: 0, max: 110 })
    .withMessage('Age needs to be a number between 0 and 110!'),
  body('birthYear')
    .optional()
    .isInt({ min: 1900, max: new Date().getFullYear() })
    .withMessage(
      'Birth Year is required and has to be a 4 digit number between 1900 and the current year!',
    ),
  body('quote')
    .optional()
    .trim()
    .isLength({ min: 2, max: 1000 })
    .withMessage('A Quote is required to be between 2 and 1000 characters'),
];

const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  return next();
};

// Validation rules for programming languages
const validateProgrammingLanguageData = [
  body('name')
    .notEmpty()
    .withMessage('Name is required.')
    .isString()
    .withMessage('Name must be a string.')
    .isLength({ min: 2, max: 40 })
    .withMessage('Name must be between 2 and 40 characters.'),
  body('paradigm')
    .notEmpty()
    .withMessage('Paradigm is required.')
    .isArray({ min: 1 })
    .withMessage('Paradigm must be a non-empty array.'),
  body('paradigm.*')
    .isString()
    .withMessage('Paradigm must be a string.')
    .isLength({ min: 2, max: 20 })
    .withMessage('Paradigm must be between 2 and 20 characters.'),
  body('firstAppeared')
    .notEmpty()
    .withMessage('First appeared is required.')
    .isNumeric()
    .withMessage('First appeared must be a number.')
    .isLength({ min: 4, max: 4 })
    .withMessage('First appeared must be a 4-digit year.'),
  body('creator')
    .notEmpty()
    .withMessage('Creator is required.')
    .isString()
    .withMessage('Creator must be a string.')
    .isLength({ min: 2, max: 40 })
    .withMessage('Creator must be between 2 and 40 characters.'),
  body('website')
    .optional()
    .isURL()
    .withMessage('Website must be a valid URL.'),
  body('description')
    .optional()
    .isString()
    .withMessage('Description must be a string.')
    .isLength({ max: 300 })
    .withMessage('Description must be at most 300 characters.'),
];

module.exports = {
  validateObjectId,
  validateMovieData,
  validateRecipeRules,
  validateRecipeUpdateRules,
  validateRecipeNameRules,
  validateScriptureData,
  handleValidationErrors,
  validateBookData,
  validateBookArray,
  validateSpeakerData,
  validateSpeakerUpdateData,
  validateProgrammingLanguageData,
};
