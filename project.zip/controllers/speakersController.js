const { default: mongoose } = require('mongoose');
const Speaker = require('../schemas/SpeakerSchema');

const getAllSpeakers = async (req, res) => {
  //#swagger.tags = ['Speakers']
  //#swagger.summary = 'Gets all speakers.'
  try {
    const result = await Speaker.find();
    if (result.length === 0) {
      return res.status(404).json({ error: 'Your speakers were not found' });
    }
    return res.status(200).json(result);
  } catch (error) {
    return res
      .status(500)
      .json({ error: 'There was an error while getting your speaker' });
  }
};

const getSpeaker = async (req, res) => {
  //#swagger.tags = ['Speakers']
  //#swagger.summary = 'Gets a speaker by ID.'
  const { id } = req.params;
  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ error: 'You passed an invalid ID' });
    }
    const result = await Speaker.findById(id);
    if (!result) {
      return res.status(404).json({ error: 'Your speaker was not found' });
    }
    return res.status(200).json(result);
  } catch (error) {
    return res
      .status(500)
      .json({ error: 'There was an error while getting your speaker' });
  }
};

const createSpeaker = async (req, res) => {
  //#swagger.tags = ['Speakers']
  //#swagger.summary = 'Creates a new speaker.'
  try {
    const result = new Speaker({
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      age: req.body.age,
      birthYear: req.body.birthYear,
      quote: req.body.quote,
    });
    await result.save();
    return res.status(201).json(result);
  } catch (error) {
    if (error.name === 'ValidationError') {
      const message = Object.values(error.errors).map((e) => e.message);
      return res
        .status(400)
        .json({ error: 'ValidationError', details: message });
    }
    return res
      .status(500)
      .json({ error: 'There was an error while creating your speaker' });
  }
};

const updateSpeaker = async (req, res) => {
  //#swagger.tags = ['Speakers']
  //#swagger.summary = 'Updates a speaker by ID.'
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ error: 'You passed in an invalid ID' });
    }

    const speakerData = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      age: req.body.age,
      birthYear: req.body.birthYear,
      quote: req.body.quote,
    };

    const result = await Speaker.findByIdAndUpdate(id, speakerData, {
      new: true,
      runValidators: true,
      context: 'query',
    });

    if (!result) {
      return res.status(404).json({ error: 'Your speaker was not found' });
    }

    return res.status(200).json({
      message: 'Your speaker was updated!',
      updatedSpeaker: result,
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const message = Object.values(error.errors).map((e) => e.message);
      return res
        .status(400)
        .json({ error: 'ValidationError', details: message });
    }
    return res
      .status(500)
      .json({ error: 'There was an error while updating your speaker' });
  }
};

const deleteSpeaker = async (req, res) => {
  //#swagger.tags = ['Speakers']
  //#swagger.summary = 'Deletes a speaker by ID.'
  const { id } = req.params;
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ error: 'You passed in an invalid ID' });
  }
  try {
    const result = await Speaker.findByIdAndDelete(id);
    if (!result) {
      return res.status(404).json({ error: 'Your speaker was not found' });
    }
    return res
      .status(200)
      .json({ message: 'Your speaker was deleted', speaker: result });
  } catch (error) {
    return res
      .status(500)
      .json({ error: 'There was an error while deleting your speaker' });
  }
};

module.exports = {
  getAllSpeakers,
  getSpeaker,
  createSpeaker,
  updateSpeaker,
  deleteSpeaker,
};
